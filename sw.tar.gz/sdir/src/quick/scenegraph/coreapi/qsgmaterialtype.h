// Copyright (C) 2019 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#ifndef QSGMATERIALTYPE_H
#define QSGMATERIALTYPE_H

#include <QtQuick/qtquickglobal.h>

QT_BEGIN_NAMESPACE

struct QSGMaterialType { };

QT_END_NAMESPACE

#endif
